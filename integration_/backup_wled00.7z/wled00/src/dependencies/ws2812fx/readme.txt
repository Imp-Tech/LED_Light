https://github.com/kitesurfer1404/WS2812FX/

The WS2812FX implementation was heavily altered and differs from its master branch.
Due to regular changes to the library code it is kept in the source dir for now.
